var demoConfig={
	"_id": "demo",
	"members": [
			{
				"_id":0,
				"host":"localhost:30000",
				"priority":10
			},
			{
				"_id":1,
				"host":"localhost:40000"
			},
			{
				"_id":2,
				"host":"localhost:50000",
				"arbiterOnly":true
			}
	]
}

// rs.initiate(demoConfig)
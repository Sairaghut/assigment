db.users.insertMany(
   [
     { name: "Sagar", age: 41, status: "A", },
     { name: "Sanjay", age: 37, status: "A", },
     { name: "Anuradha", age: 33, status: "D", }
   ]
)
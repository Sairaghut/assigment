db.users.insertOne(
   {
      name: "Renu",
      age: 11,
      status: "P"
   }
)
db.users.insert(
   [
     { name: "Vivek", age: 36, status: "A", },
     { name: "Ahana", age: 9, status: "A", },
     { name: "Ravi", age: 57, status: "D", }
   ]
)
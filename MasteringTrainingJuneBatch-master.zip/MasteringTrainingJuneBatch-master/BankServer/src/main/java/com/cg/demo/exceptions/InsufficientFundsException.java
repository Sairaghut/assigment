package com.cg.demo.exceptions;

public class InsufficientFundsException extends Exception {

}

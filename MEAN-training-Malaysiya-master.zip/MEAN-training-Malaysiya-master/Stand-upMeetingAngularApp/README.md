### Base Template for StandupMeeting App

This is static application.

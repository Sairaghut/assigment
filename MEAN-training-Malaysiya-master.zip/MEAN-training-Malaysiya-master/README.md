# MEAN training demo code.

1. Advanced java script 
2. AngularJS Application
3. Node application with Mongoose
 
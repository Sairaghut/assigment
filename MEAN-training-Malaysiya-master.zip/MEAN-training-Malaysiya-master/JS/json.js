/**
 * Created by sagakulk on 7/16/2016.
 */

var x={
   name:'How to Learn JS in 2 days',
   text:'some text',
   author:{
       name:'Sagar',
       email:'kulsagar@hotmail.com',
       address:{

       }
   },
   comments:[
       {text:'aaa', user:'Ravi'},{}  ]
}
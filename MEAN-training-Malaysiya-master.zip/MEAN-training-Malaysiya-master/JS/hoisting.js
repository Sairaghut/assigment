/**
 * Created by sagakulk on 7/16/2016.
 */
/*console.log(x);
var x=10;
function x(){
    console.log("funny JS");
}*/
//////////////////////////////

function x(){
    console.log("funny JS");
}
//var x;
console.log(x.toString());
x.z=5;

x();


/*var x=50;

var x;

console.log(x);


*/










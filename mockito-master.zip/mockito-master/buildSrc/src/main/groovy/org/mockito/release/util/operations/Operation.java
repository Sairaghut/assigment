package org.mockito.release.util.operations;

public interface Operation {
    void perform();
}

package com.bank.exceptions;

public class AccountCreationFaliedException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}

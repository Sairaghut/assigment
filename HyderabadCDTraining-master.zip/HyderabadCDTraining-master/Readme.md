## This is my First Repository

# I am new to Git

1. Create an empty folder
2. Type following git command
	`git init`
	
3. Create Readme.md file
4. add some coll stuff in that file
5. Type following commnad to stage the file for commit
	`git add Readme.md`

6. Commit the changes to your local repo by typing following command
	`git commit -m 'meaningful commit message'`

7. Push the changes to your remote repo
	`git push https://github.com/kulsagar/HyderabadCDTraining.git'
	
This is merge demo. 
If I do it without making any mistake then I can take off for the rest of the day.

Adding a new line on 21st 
Hello All

for more git commands, refer to following document
https://education.github.com/git-cheat-sheet-education.pdf

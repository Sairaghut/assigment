package com.cg.demo.merge;

public class MergeTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello By Sagar");
		System.out.println("Hello world by Skharab");
		System.out.println("Hello world by Skharab");
		
		System.out.println("How wil you get this?");
		System.out.println("Hello Abhi");


	}

}

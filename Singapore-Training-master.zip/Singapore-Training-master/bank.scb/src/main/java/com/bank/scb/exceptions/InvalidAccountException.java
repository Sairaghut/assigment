package com.bank.scb.exceptions;

public class InvalidAccountException extends Exception {

}

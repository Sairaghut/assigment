package com.bank.scb.exceptions;

public class InsufficientAmountException extends Exception {

}

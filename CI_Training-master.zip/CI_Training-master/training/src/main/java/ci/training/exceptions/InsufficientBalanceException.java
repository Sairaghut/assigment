package ci.training.exceptions;

public class InsufficientBalanceException extends RuntimeException {

	public InsufficientBalanceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InsufficientBalanceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}

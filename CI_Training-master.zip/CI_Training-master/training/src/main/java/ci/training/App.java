package ci.training;

/**
 * Hello world!
 *
 */
public class App{
	
	private App(){}
	
    public static void main( String[] args ){
    	
        System.out.println( "Hello World!" );
    }
}

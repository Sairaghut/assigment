# This is a demo repository

Type following commands to get this repository  

`
git init`

`git pull https://github.com/kulsagar/Mastering_CI_Chennai.git  
`

This Demo code for CI.
package com.cg.demo.exceptions;

public class InvalidInitialAmountException extends Exception {

}

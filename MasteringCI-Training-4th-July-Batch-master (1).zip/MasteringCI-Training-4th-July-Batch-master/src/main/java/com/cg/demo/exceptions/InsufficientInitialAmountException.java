package com.cg.demo.exceptions;

public class InsufficientInitialAmountException extends Exception {

}
